
import React, { useRef, useEffect } from 'react';
import { Climber, Hold, LimbId, Limb } from '../types';
import { CANVAS_WIDTH, CANVAS_HEIGHT, MAX_REACH } from '../constants';

interface Props {
  climber: Climber;
  holds: Hold[];
  activeLimb: LimbId | null;
  draggingLimb: LimbId | null;
  mousePos: { x: number; y: number };
  isFalling: boolean;
  hintPath: string[];
  onMouseDown: (x: number, y: number) => void;
  onMouseMove: (x: number, y: number) => void;
  onMouseUp: () => void;
}

const ClimbingCanvas: React.FC<Props> = ({ 
  climber, holds, activeLimb, draggingLimb, mousePos, isFalling, hintPath,
  onMouseDown, onMouseMove, onMouseUp 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#d4c5a9';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Wood grain
    ctx.strokeStyle = '#c2b395';
    ctx.lineWidth = 1;
    for (let i = 0; i < CANVAS_HEIGHT; i += 40) {
        ctx.beginPath();
        ctx.moveTo(0, i + Math.random() * 20);
        ctx.quadraticCurveTo(CANVAS_WIDTH/2, i + Math.random()*10, CANVAS_WIDTH, i + Math.random()*20);
        ctx.stroke();
    }

    // Bolt Grid
    ctx.fillStyle = 'rgba(0,0,0,0.1)';
    const gridSize = 80;
    for (let x = gridSize/2; x < CANVAS_WIDTH; x += gridSize) {
        for (let y = gridSize/2; y < CANVAS_HEIGHT; y += gridSize) {
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();
        }
    }
    
    // Hint Path Glow
    if (hintPath.length > 0) {
        ctx.save();
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.3)';
        ctx.lineWidth = 15;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        hintPath.forEach((id, idx) => {
            const h = holds.find(h => h.id === id);
            if (h) {
                if (idx === 0) ctx.moveTo(h.x, h.y);
                else ctx.lineTo(h.x, h.y);
            }
        });
        ctx.stroke();
        ctx.restore();
    }

    // Holds
    holds.forEach(hold => {
      ctx.save();
      ctx.translate(hold.x, hold.y);
      ctx.rotate(hold.rotation);
      
      const s = hold.size;
      const hColor = hold.color;
      const isHint = hintPath.includes(hold.id);
      
      ctx.shadowBlur = isHint ? 15 : 8;
      ctx.shadowColor = isHint ? 'rgba(16, 185, 129, 0.8)' : 'rgba(0,0,0,0.4)';
      ctx.shadowOffsetY = 5;

      ctx.beginPath();
      ctx.fillStyle = hColor;

      switch(hold.type) {
        case 'jug': ctx.roundRect(-s, -s/1.5, s*2, s*1.3, 8); break;
        case 'crimp': ctx.rect(-s, -3, s*2, 7); break;
        case 'sloper': ctx.ellipse(0, 0, s*1.5, s*0.9, 0.2, 0, Math.PI*2); break;
        case 'pinch': ctx.rect(-s/2.5, -s, 7, s*2); ctx.rect(s/2.5 - 7, -s, 7, s*2); break;
        case 'volume': ctx.moveTo(-s*1.8, 0); ctx.lineTo(0, -s*1.8); ctx.lineTo(s*1.8, 0); ctx.lineTo(0, s*1.8); ctx.closePath(); break;
        default: ctx.arc(0, 0, s, 0, Math.PI * 2);
      }
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.strokeStyle = isHint ? '#fff' : 'rgba(255,255,255,0.4)';
      ctx.lineWidth = isHint ? 3.5 : 2.5;
      ctx.stroke();

      const isAttached = (Object.values(climber.limbs) as Limb[]).some(l => l.holdId === hold.id);
      if (isAttached) {
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 3;
        ctx.setLineDash([3, 5]);
        ctx.beginPath();
        ctx.arc(0, 0, s + 6, 0, Math.PI*2);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      
      if (hold.label) {
          ctx.restore(); ctx.save(); ctx.translate(hold.x, hold.y);
          ctx.fillStyle = 'white'; ctx.font = 'bold 16px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.shadowBlur = 4; ctx.shadowColor = 'black';
          ctx.fillText(hold.label, 0, 0);
      }
      ctx.beginPath(); ctx.fillStyle = '#111'; ctx.arc(0, 0, 3.5, 0, Math.PI*2); ctx.fill();
      ctx.restore();
    });

    // Reach Circle
    if (draggingLimb || activeLimb) {
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.lineWidth = 2;
      ctx.setLineDash([10, 15]);
      ctx.arc(climber.torso.x, climber.torso.y, MAX_REACH, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Climber
    const { torso, limbs } = climber;
    ctx.lineWidth = 11;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0f172a'; 

    (Object.values(limbs) as Limb[]).forEach(limb => {
      const isDragging = draggingLimb === limb.id;
      const endX = isDragging ? mousePos.x : limb.x;
      const endY = isDragging ? mousePos.y : limb.y;
      const dist = Math.sqrt(Math.pow(endX - torso.x, 2) + Math.pow(endY - torso.y, 2));
      const inReach = dist <= MAX_REACH;

      ctx.save();
      if (!inReach) { ctx.strokeStyle = '#ef4444'; ctx.shadowBlur = 12; ctx.shadowColor = 'rgba(239, 68, 68, 0.6)'; }

      ctx.beginPath();
      ctx.moveTo(torso.x, torso.y);
      const bendFactor = (limb.id.includes('L') ? -1 : 1) * 20;
      const midX = (torso.x + endX) / 2 + bendFactor;
      const midY = (torso.y + endY) / 2 + 15;
      ctx.quadraticCurveTo(midX, midY, endX, endY);
      ctx.stroke();

      ctx.beginPath();
      ctx.fillStyle = (activeLimb === limb.id || isDragging) ? '#fff' : '#475569';
      if (isDragging) { ctx.shadowBlur = 30; ctx.shadowColor = 'white'; }
      ctx.arc(endX, endY, 11, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = (activeLimb === limb.id || isDragging) ? '#000' : '#fff';
      ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(limb.id, endX, endY);
      ctx.restore();
    });

    // Torso/Head
    ctx.fillStyle = '#0f172a';
    ctx.beginPath(); ctx.ellipse(torso.x, torso.y, 18, 30, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(torso.x, torso.y - 45, 14, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#10b981';
    ctx.beginPath(); ctx.arc(torso.x, torso.y - 48, 12, Math.PI, 0); ctx.fill();

  }, [climber, holds, activeLimb, draggingLimb, mousePos, isFalling, hintPath]);

  const getCanvasCoords = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return { x: (e.clientX - rect.left) * scaleX, y: (e.clientY - rect.top) * scaleY };
  };

  return (
    <canvas 
      ref={canvasRef}
      width={CANVAS_WIDTH}
      height={CANVAS_HEIGHT}
      onMouseDown={(e) => { const c = getCanvasCoords(e); onMouseDown(c.x, c.y); }}
      onMouseMove={(e) => { const c = getCanvasCoords(e); onMouseMove(c.x, c.y); }}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      className={`w-full h-full object-contain ${draggingLimb ? 'cursor-grabbing' : 'cursor-grab'}`}
    />
  );
};

export default ClimbingCanvas;
