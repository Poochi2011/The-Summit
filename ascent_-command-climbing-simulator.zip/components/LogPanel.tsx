
import React from 'react';
import { GameLog } from '../types';

interface Props {
  logs: GameLog[];
}

const LogPanel: React.FC<Props> = ({ logs }) => {
  return (
    <div className="flex-1 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden flex flex-col shadow-xl">
      <div className="px-4 py-3 bg-slate-800/50 border-b border-slate-800 flex justify-between items-center">
        <h3 className="text-sm font-semibold text-slate-300">Activity Log</h3>
        <span className="text-[10px] text-slate-500 uppercase tracking-widest">Real-time</span>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-2 font-mono text-xs">
        {logs.length === 0 && (
            <div className="h-full flex items-center justify-center text-slate-600 italic">
                No activity yet...
            </div>
        )}
        {logs.map((log) => (
          <div 
            key={log.id} 
            className={`border-l-2 pl-3 py-1 transition-all animate-in slide-in-from-left duration-300 ${
              log.type === 'error' ? 'border-red-500 text-red-400 bg-red-950/20' : 
              log.type === 'success' ? 'border-emerald-500 text-emerald-400 bg-emerald-950/20' : 
              'border-blue-500 text-blue-300 bg-blue-950/20'
            }`}
          >
            <div className="flex justify-between items-start opacity-80">
                <span className="font-bold">{log.message}</span>
                <span className="text-[9px] text-slate-500 whitespace-nowrap ml-2">
                    {log.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LogPanel;
