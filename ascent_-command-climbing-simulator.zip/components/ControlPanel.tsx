
import React, { useState } from 'react';
import { LimbId, Color } from '../types';

interface Props {
  onCommand: (cmd: string) => void;
  onLimbSelect: (limb: LimbId) => void;
  onQuickMove: (color: Color) => void;
  activeLimb: LimbId | null;
  availableColors: readonly string[];
}

const ControlPanel: React.FC<Props> = ({ onCommand, onLimbSelect, onQuickMove, activeLimb, availableColors }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onCommand(inputValue);
      setInputValue('');
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-4 shadow-xl">
      <div className="flex items-center gap-4">
        {/* Limb Selection */}
        <div className="flex gap-2">
          {(['LH', 'RH', 'LF', 'RF'] as LimbId[]).map(id => (
            <button
              key={id}
              onClick={() => onLimbSelect(id)}
              className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-xs transition-all border ${
                activeLimb === id 
                  ? 'bg-emerald-500 text-white border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]' 
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-500'
              }`}
            >
              {id}
            </button>
          ))}
        </div>

        {/* Color Shortcuts */}
        <div className="flex gap-2 border-l border-slate-800 pl-4">
          {availableColors.map(color => (
            <button
              key={color}
              onClick={() => onQuickMove(color as Color)}
              className="w-8 h-8 rounded-full border-2 border-slate-800 hover:scale-110 transition-transform"
              style={{ backgroundColor: color }}
              title={`Move to ${color}`}
            />
          ))}
        </div>

        {/* Command Input */}
        <form onSubmit={handleSubmit} className="flex-1">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type command... (e.g. 'move RH to red')"
            className="w-full bg-slate-950 text-slate-100 border border-slate-800 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-slate-600"
          />
        </form>
      </div>
      <div className="text-[10px] text-slate-500 flex justify-between px-1">
        <span>Active Limb: {activeLimb || 'None'}</span>
        <span>Tip: Maintaining center of gravity is key!</span>
      </div>
    </div>
  );
};

export default ControlPanel;
